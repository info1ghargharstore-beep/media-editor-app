import React, { useState, useCallback } from 'react';
import './App.css';
import UploadSection from './components/UploadSection';
import ProcessingPanel from './components/ProcessingPanel';
import FileList from './components/FileList';
import Preview from './components/Preview';

function App() {
  const [uploadedFile, setUploadedFile] = useState(null);
  const [processedFiles, setProcessedFiles] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [previewFile, setPreviewFile] = useState(null);
  const [stats, setStats] = useState(null);

  const handleFileUpload = useCallback((file) => {
    setUploadedFile(file);
    fetchStats();
  }, []);

  const handleProcessing = useCallback((result) => {
    setProcessedFiles(prev => [...prev, result]);
    setIsProcessing(false);
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  React.useEffect(() => {
    fetchStats();
  }, []);

  return (
    <div className="app">
      <header className="app-header">
        <h1>🎨 Advanced Media Editor</h1>
        <p>Edit, clean, and reveal hidden content in PDFs and images</p>
      </header>

      <main className="app-main">
        <div className="app-container">
          <UploadSection onFileUpload={handleFileUpload} />
          
          {uploadedFile && (
            <>
              <Preview file={uploadedFile} onPreviewChange={setPreviewFile} />
              <ProcessingPanel 
                file={uploadedFile}
                onProcessing={() => setIsProcessing(true)}
                onProcessComplete={handleProcessing}
              />
            </>
          )}

          {processedFiles.length > 0 && (
            <FileList files={processedFiles} />
          )}

          {stats && (
            <div className="stats-panel">
              <h3>📊 Statistics</h3>
              <div className="stats-grid">
                <div className="stat-item">
                  <span className="stat-label">Files Uploaded</span>
                  <span className="stat-value">{stats.uploaded_files}</span>
                </div>
                <div className="stat-item">
                  <span className="stat-label">Files Processed</span>
                  <span className="stat-value">{stats.processed_files}</span>
                </div>
                <div className="stat-item">
                  <span className="stat-label">Total Size</span>
                  <span className="stat-value">{(stats.total_size / 1024 / 1024).toFixed(2)} MB</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;