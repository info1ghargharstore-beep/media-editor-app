import React, { useState } from 'react';
import '../styles/ProcessingPanel.css';

const ProcessingPanel = ({ file, onProcessing, onProcessComplete }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState(null);

  const processFile = async (action) => {
    setIsLoading(true);
    onProcessing();

    try {
      const response = await fetch(`http://localhost:5000/api/${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: file.filename })
      });

      const data = await response.json();
      if (data.success) {
        setResults(data);
        onProcessComplete(data);
      } else {
        alert(`Error: ${data.error}`);
      }
    } catch (error) {
      console.error('Processing error:', error);
      alert('Processing failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="processing-panel">
      <h3>Processing Options</h3>
      <div className="button-grid">
        <button 
          onClick={() => processFile('remove-blocks')}
          disabled={isLoading}
          className="btn-primary"
        >
          🚫 Remove Blocks
        </button>
        <button 
          onClick={() => processFile('reveal-hidden')}
          disabled={isLoading}
          className="btn-primary"
        >
          👁️ Reveal Hidden
        </button>
        <button 
          onClick={() => processFile('enhance-image')}
          disabled={isLoading}
          className="btn-primary"
        >
          ✨ Enhance Image
        </button>
        <button 
          onClick={() => processFile('compress')}
          disabled={isLoading}
          className="btn-primary"
        >
          📦 Compress
        </button>
      </div>
      {results && (
        <div className="results-panel">
          <h4>✅ Processing Complete</h4>
          <pre>{JSON.stringify(results, null, 2)}</pre>
          <a 
            href={`http://localhost:5000/api/download/${results.result_filename}`}
            className="download-btn"
            download
          >
            📥 Download Result
          </a>
        </div>
      )}
    </div>
  );
};

export default ProcessingPanel;