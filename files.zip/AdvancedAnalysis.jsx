import React, { useState } from 'react';

const AdvancedAnalysis = ({ file }) => {
  const [analysisType, setAnalysisType] = useState(null);
  const [results, setResults] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const runAnalysis = async (type) => {
    setIsLoading(true);
    setAnalysisType(type);

    try {
      let endpoint = '';
      
      switch(type) {
        case 'image':
          endpoint = '/api/advanced/analyze-image';
          break;
        case 'pdf':
          endpoint = '/api/advanced/pdf-analysis';
          break;
        case 'steganography':
          endpoint = '/api/advanced/steganography-detection';
          break;
        case 'encryption':
          endpoint = '/api/advanced/encryption-analysis';
          break;
        case 'extract':
          endpoint = '/api/advanced/extract-hidden';
          break;
        default:
          return;
      }

      const response = await fetch(`http://localhost:5000${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: file.filename })
      });

      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error('Analysis error:', error);
      alert('Analysis failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="advanced-analysis">
      <h3>🔬 Advanced Analysis</h3>
      
      <div className="analysis-buttons">
        <button onClick={() => runAnalysis('image')} disabled={isLoading}>
          📸 Analyze Image
        </button>
        <button onClick={() => runAnalysis('pdf')} disabled={isLoading}>
          📄 Analyze PDF
        </button>